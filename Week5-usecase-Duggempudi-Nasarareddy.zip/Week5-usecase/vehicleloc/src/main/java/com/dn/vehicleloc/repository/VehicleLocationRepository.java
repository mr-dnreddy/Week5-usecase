package com.dn.vehicleloc.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dn.vehicleloc.entity.VehicleLocation;

@Repository
public interface VehicleLocationRepository extends JpaRepository<VehicleLocation, Integer> {
}
