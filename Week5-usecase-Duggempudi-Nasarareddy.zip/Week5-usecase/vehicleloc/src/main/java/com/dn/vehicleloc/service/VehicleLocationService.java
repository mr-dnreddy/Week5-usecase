package com.dn.vehicleloc.service;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.dn.vehicleloc.entity.VehicleLocation;
import com.dn.vehicleloc.repository.VehicleLocationRepository;

@Service
public class VehicleLocationService {

    @Autowired
    private VehicleLocationRepository repository;

    @Autowired
    private KafkaTemplate<String, VehicleLocation> kafkaTemplate;

    private boolean generating = false;
    private final Random random = new Random();

    public VehicleLocation save(VehicleLocation vehicleLocation) {
        return repository.save(vehicleLocation);
    }

    public List<VehicleLocation> findAll() {
        return repository.findAll();
    }

    public void startGeneratingLocations() {
        generating = true;
        new Thread(() -> {
            while (generating) {
                List<VehicleLocation> vehicles = repository.findAll();
                for (VehicleLocation vehicle : vehicles) {
                    double lat = round(random.nextDouble() * 180 - 90, 2);
                    double longitude = round(random.nextDouble() * 360 - 180, 2);
                    vehicle.setLat(lat);
                    vehicle.setLongitude(longitude);
                    repository.save(vehicle);
                    kafkaTemplate.send("vehicle_location", vehicle);
                }
                try {
                    Thread.sleep(5000); // Sleep for 5 seconds
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }

    public void stopGeneratingLocations() {
        generating = false;
    }

    private double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
