package com.dn.vehicleloc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehiclelocApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehiclelocApplication.class, args);
	}

}
