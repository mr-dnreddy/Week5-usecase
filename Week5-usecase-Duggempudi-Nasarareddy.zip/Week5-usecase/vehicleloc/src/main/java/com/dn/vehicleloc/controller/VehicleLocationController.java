package com.dn.vehicleloc.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dn.vehicleloc.entity.VehicleLocation;
import com.dn.vehicleloc.service.VehicleLocationService;

@RestController
@RequestMapping("/vehicle")
public class VehicleLocationController {

 @Autowired
 private VehicleLocationService service;

 @PostMapping
 public VehicleLocation addVehicle(@RequestBody VehicleLocation vehicleLocation) {
     return service.save(vehicleLocation);
 }

 @GetMapping
 public List<VehicleLocation> getVehicles() {
     return service.findAll();
 }

 @PostMapping("/generateloc")
 public void startGeneratingLocations() {
     service.startGeneratingLocations();
 }

 @PostMapping("/stopgen")
 public void stopGeneratingLocations() {
     service.stopGeneratingLocations();
 }
}
