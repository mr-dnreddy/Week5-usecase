package com.dn.cabbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabbookApplication.class, args);
	}

}
