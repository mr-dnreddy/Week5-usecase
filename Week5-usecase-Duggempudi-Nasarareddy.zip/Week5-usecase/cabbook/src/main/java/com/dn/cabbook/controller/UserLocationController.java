package com.dn.cabbook.controller;


import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.dn.cabbook.model.UserLocation;
import com.dn.cabbook.model.VehicleLocation;

@RestController
@RequestMapping("/cabbook")
public class UserLocationController {

 @Autowired
 private RestTemplate restTemplate;

 @PostMapping
 public String bookCab(@RequestBody UserLocation userLocation) {
     
     String vehicleLocUrl = "http://localhost:8081/vehicle";
     VehicleLocation[] vehicles = restTemplate.getForObject(vehicleLocUrl, VehicleLocation[].class);

     for (VehicleLocation vehicle : vehicles) {
         if (isMatch(userLocation, vehicle)) {
             return "Cab booked successfully for user: " + userLocation.getUserName() +
                    " with vehicle: " + vehicle.getVehicleNumber();
         }
     }
     return "No matching vehicle found for user: " + userLocation.getUserName();
 }

 private boolean isMatch(UserLocation userLocation, VehicleLocation vehicleLocation) {
     int userLatIntegral = userLocation.getLat().intValue();
     int userLongIntegral = userLocation.getLongitude().intValue();
     int vehicleLatIntegral = vehicleLocation.getLat().intValue();
     int vehicleLongIntegral = vehicleLocation.getLongitude().intValue();

     BigDecimal userLatDecimal = BigDecimal.valueOf(userLocation.getLat()).subtract(BigDecimal.valueOf(userLatIntegral));
     BigDecimal userLongDecimal = BigDecimal.valueOf(userLocation.getLongitude()).subtract(BigDecimal.valueOf(userLongIntegral));
     BigDecimal vehicleLatDecimal = BigDecimal.valueOf(vehicleLocation.getLat()).subtract(BigDecimal.valueOf(vehicleLatIntegral));
     BigDecimal vehicleLongDecimal = BigDecimal.valueOf(vehicleLocation.getLongitude()).subtract(BigDecimal.valueOf(vehicleLongIntegral));

     userLatDecimal = userLatDecimal.setScale(2, RoundingMode.HALF_UP);
     userLongDecimal = userLongDecimal.setScale(2, RoundingMode.HALF_UP);
     vehicleLatDecimal = vehicleLatDecimal.setScale(2, RoundingMode.HALF_UP);
     vehicleLongDecimal = vehicleLongDecimal.setScale(2, RoundingMode.HALF_UP);

     return userLatIntegral == vehicleLatIntegral &&
            userLongIntegral == vehicleLongIntegral &&
            userLatDecimal.subtract(vehicleLatDecimal).abs().compareTo(BigDecimal.valueOf(0.01)) <= 0 &&
            userLongDecimal.subtract(vehicleLongDecimal).abs().compareTo(BigDecimal.valueOf(0.01)) <= 0;
 }
}
