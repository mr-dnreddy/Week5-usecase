package com.dn.cabbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
